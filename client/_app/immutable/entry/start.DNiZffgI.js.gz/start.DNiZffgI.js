import{a as t}from"../chunks/entry.CQc4qIbB.js";export{t as start};
