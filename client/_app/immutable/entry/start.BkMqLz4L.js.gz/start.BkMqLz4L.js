import{a as t}from"../chunks/entry.ByKpyy_U.js";export{t as start};
