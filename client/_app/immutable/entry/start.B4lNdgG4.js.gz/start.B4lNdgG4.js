import{a as t}from"../chunks/entry.CLo78Mpl.js";export{t as start};
