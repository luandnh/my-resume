import{a as t}from"../chunks/entry.BHhpsAWo.js";export{t as start};
