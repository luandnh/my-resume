import{a as t}from"../chunks/entry.Bp2looP1.js";export{t as start};
