import{a as t}from"../chunks/entry.DOIz5hxS.js";export{t as start};
