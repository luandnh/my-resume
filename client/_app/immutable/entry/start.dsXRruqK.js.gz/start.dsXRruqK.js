import{a as t}from"../chunks/entry.CoOyiF9y.js";export{t as start};
