import{a as t}from"../chunks/entry.CaYV2Vbg.js";export{t as start};
