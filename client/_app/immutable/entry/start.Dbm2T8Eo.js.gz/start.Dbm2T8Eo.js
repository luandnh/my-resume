import{a as t}from"../chunks/entry.BPbBWzGa.js";export{t as start};
